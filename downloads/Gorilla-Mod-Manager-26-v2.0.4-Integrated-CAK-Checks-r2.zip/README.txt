GORILLA MOD MANAGER 26 v2.0.4 - INTEGRATED CAK CHECKS r2
=====================================================

SECURITY STATUS
---------------
The earlier package was flagged by Microsoft Defender as Trojan:Win32/Ulthar.A!ml
in Gorilla CAK Inspector.exe. This revision completely removes that standalone
program and its build project. Existing CAK checks remain inside the manager.
This is a functional/package revision, not a confirmed malware-free build or a
Microsoft false-positive verdict. Read ANTIVIRUS-STATUS.txt for actual scan status.
Keep antivirus protection enabled. If this build is flagged, leave it blocked;
do not allow it or add an exclusion. The earlier package remains withdrawn.

This is an unofficial modified copy of the supplied v2.0.4 package. Original
author: Mr Creeper HD. Original mod management, TRIBUTE, Discovery, backup,
restore and update code are retained. See README.original.txt.

USE THE INTEGRATED CHECKS
-------------------------
1. Let your antivirus inspect the new download. Continue only if it allows it.
2. Extract to a NEW folder. Do not copy files over the withdrawn build.
3. Keep Gorilla Mod Manager 26.exe, GorillaCrashDetails.dll, GorillaReader.dll
   and GorillaReader.runtimeconfig.json together. The new DLL is required.
4. Open the manager on Windows, then FIX MY GAME > CHECK AGAIN.
5. CAK file inspection reads enabled, top-level .cak files in the configured
   mods folder. Use the existing Add a Mod page for installation. Disabled
   files and subfolders are excluded from the automatic inspection.
6. Read the crash explanation, CAK file cards, shared asset IDs and any quoted
   CakeHook messages. OPEN FOLDER on the crash card opens a saved local report.

There is no standalone CAK Inspector in this revision. No separate executable
is required for the integrated checks. A file outside the configured mods
folder is not automatically inspected.

WHAT IS CHECKED
----------------
- Windows crash/hang time, faulting component, exception code and offset,
  when Windows supplies them, with confidence and suggested next checks.
- Actual FDIR CAK bytes and supported plaintext file/directory tables, names,
  asset IDs, chunk metadata and payload bounds. This can expose empty files,
  incorrect extensions, broken tables, invalid references and truncated data.
- Shared asset IDs between enabled CAKs. These can be intentional replacements;
  an overlap is a lead, not proof of a conflict or crash cause.
- CakeHook messages mentioning the filename, when present, from the last marked
  session. Stale logs are flagged. A filename mention may be a successful load.

Plaintext formats supported: 6.7, 6.8, 8.1, 8.2, 8.3, 8.7, 9.1, 9.2, 9.3.
Encrypted metadata and other versions, including 9.9, are marked LIMITED.
Their entries/integrity are NOT validated. Encryption or an unsupported version
does not prove corruption. Checksums, compressed/encrypted asset contents,
model/texture correctness and exact game compatibility are not validated.

Inspection limits: 32 MiB metadata and 100,000 entries per CAK; 256 enabled
archives and 200,000 distinct asset IDs in an automatic scan. Up to 20 file
cards and 12 overlap cards are shown. Reaching a limit is reported explicitly.
The check never extracts, edits, deletes or disables a CAK.

If evidence is insufficient, the report says the cause is unknown. A crash
inside a plugin, an access violation or a shared Windows DLL cannot by itself
identify which mod introduced the underlying fault. Use repeated comparable
tests and the existing backup/restore controls to investigate a suspect.

LOCAL REPORTS
---------------
The latest report is saved in Crash Reports/Latest crash report.txt under
Gorilla's data folder. It is saved locally only and may contain personal file
paths. Review it before sharing. Only the latest report is retained.

REQUIREMENTS AND LIMITS
------------------------
- Windows with .NET Framework 4.8 for the original desktop app and add-on.
- The original GorillaReader helper targets .NET 10. If that runtime is missing,
  obtain Microsoft's x64 .NET 10 Runtime from the official Microsoft download site:
  https://dotnet.microsoft.com/download/dotnet/10.0
- A WWE 2K26 installation and available Windows Application event records.
- This Linux build environment cannot run Microsoft Defender, the Windows UI or
  WWE 2K26. Functional and package checks do not establish malware safety.
- Your particular CAK has not been supplied or examined here.
- This patch accepts only the exact uploaded v2.0.4 executable. An official
  update may replace the report hook and requires a separately reviewed patch.

Format research credit: Nenkai/Bakery. See THIRD-PARTY-NOTICES.txt.
