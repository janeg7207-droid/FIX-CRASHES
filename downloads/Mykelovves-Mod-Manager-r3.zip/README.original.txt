GORILLA MOD MANAGER 26  -  version 2.0.4  -  free  -  by Mr Creeper HD
=====================================================================

INSTALL
-------
1. Unzip anywhere (Desktop is fine).
2. Keep these 3 files together:
     Gorilla Mod Manager 26.exe
     GorillaReader.dll
     GorillaReader.runtimeconfig.json
3. Start Gorilla Mod Manager 26.exe.

It finds WWE 2K26, TRIBUTE and Discovery by itself.
Not found? Click "Folders" at the bottom and show it where they are.
Close the game, TRIBUTE and Discovery (Meta) before you change anything.


WHAT EACH PAGE DOES
-------------------
HOME
  Play WWE 2K26. After you added something to TRIBUTE or Discovery,
  it says "OPEN TRIBUTE" / "OPEN DISCOVERY": open it, bake, then play.

ADD A MOD
  Drag in a .zip, a .cak or a Gorilla pack (.gorillamod).
  It shows what is inside BEFORE anything changes. Press ADD.
  - Mod files (.cak) go into the game's mods folder.
  - Entrances, victories, moves, weapons go into TRIBUTE or Discovery.
    Bake after adding to see them in the game.
  - Number already used by another mod? It gets a free number, so both work.
  - It never replaces anything of yours.
  - Character mods: add them with TRIBUTE / Discovery.

MY MODS
  Every mod file in your game. Turn one on or off with one click.
  "Off" moves it aside, it is not deleted.

MY TRIBUTE / MY DISCOVERY
  Everything inside your TRIBUTE or Discovery, by tabs:
  Moves, Taunts, Entrances, Victories, Weapons, Packs.
  - Remove takes out only that one item. Everything else stays.
  - Removed tab: Put back brings it back. Delete permanently frees space.
  Bake after a change.

GO BACK
  Every change Gorilla made, newest first. Undo any of them.
  It also keeps your last working setup.

FIX MY GAME
  Game crashing after mods? It helps you find the mod that breaks it.

CHECK FOR UPDATES (bottom)
  New versions come inside the app. Nothing installs until you press it.


SAFE
----
- Nothing is deleted without asking.
- Old files are kept in "Gorilla Backups" before every change.
- If something goes wrong, use GO BACK.


HELP
----
Bug or question? Post in the Gorilla Mod Manager channel on Discord
with a screenshot.


