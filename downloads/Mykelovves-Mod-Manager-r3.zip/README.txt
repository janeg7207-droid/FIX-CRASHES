MYKELOVVES MOD MANAGER r3
========================
Same-file comparisons, CAK inspection and crash investigation

Based on the supplied Gorilla Mod Manager 26 v2.0.4 by Mr Creeper HD.
This is an unofficial modification with the name requested by the user.
Original mod management, TRIBUTE, Discovery, backup, restore, mod search and
update code are retained. See README.original.txt for the original credits.
Existing data/settings paths and internal resource names stay compatible.
Official updates may replace the added hooks and branding.

SECURITY STATUS
---------------
The earlier standalone Gorilla CAK Inspector.exe was flagged by Microsoft
Defender as Trojan:Win32/Ulthar.A!ml. That program and its project were removed
in r2; r3 keeps them excluded. The main manager's requested name change does
not reintroduce or replace that standalone program.
This package has NOT received antivirus clearance or a Microsoft false-positive
verdict. Read ANTIVIRUS-STATUS.txt. Keep antivirus protection enabled and leave
any detection blocked; do not add an exclusion. The flagged build stays withdrawn.

USE THE CHECKS
--------------
1. Let Windows protection inspect the download. Continue only if it allows it.
2. Extract to a NEW folder, separate from the withdrawn build.
3. Keep Mykelovves Mod Manager.exe, MykelovvesDiagnostics.dll, GorillaReader.dll
   and GorillaReader.runtimeconfig.json together. The diagnostic DLL is required.
4. Launch Mykelovves Mod Manager.exe, then FIX MY GAME > CHECK AGAIN.
5. The scan reads enabled, top-level .cak files in the configured mods folder.
   Use the original Add a Mod page to install a CAK. Disabled files, subfolders
   and files outside that folder are excluded from this automatic scan.
6. Read the crash explanation, SAME FILES AND CAK INSPECTION, shared-file cards
   and CRASH INVESTIGATION. OPEN FOLDER on the report cards opens local reports.

WHAT THE RESULTS MEAN
---------------------
- Identical whole CAK files: named archives have matching whole-file SHA-256.
- Identical stored bytes: the exact internal path exists in the named CAKs and
  the stored payload hashes match. Every owner and matching subset is listed.
- Different stored versions: the same internal path has different stored bytes
  in the named CAKs. Different compression or encryption may explain this;
  it is not proof of incompatible decoded content or a game crash.
- Shared asset ID, different path names: identity is unconfirmed, not a claim
  that these are the same internal file.
- Confirmed structural/read problem: a named CAK has invalid tables, references
  or payload bounds, or could not be read. An exact internal path is included
  when the defective entry is known. Its connection to a crash remains unproven.
- Recent CakeHook error text: a quoted error mentions this exact CAK in the last
  marked log session, and the log is newer than the file. This is a lead, not
  a confirmed cause. Stale/unmarked logs do not become current error evidence.
- Mod search isolated: the original search's recorded result names the archive
  implicated by the user's test rounds. It does not identify an internal asset.

The crash explanation includes Windows event time, faulting component,
exception code, offset, confidence and suggested checks when available.
Identical files, shared paths, timing or a faulting Windows/plugin DLL alone
cannot establish the exact root cause. No cause is invented when evidence is
missing. Repeat the same scene with the suspected archive off and restored,
using the existing backup and mod-search controls. Logs or a crash dump may
still be needed to identify the exact internal file.

SUPPORTED CAKS AND LIMITS
-------------------------
Plaintext FDIR versions: 6.7, 6.8, 8.1, 8.2, 8.3, 8.7, 9.1, 9.2, 9.3.
Headers, table structure, names, IDs, chunk metadata and payload bounds are read.
Encrypted metadata and unsupported formats, including 9.9, are LIMITED, not
marked corrupt. Their entries and integrity are unverified. Payload hashing
never decompresses or decrypts; encrypted entries are compared as ciphertext.
Checksums, texture/model correctness, game compatibility and the loader's
chosen replacement winner are not established.

Limits: 256 enabled CAKs; 32 MiB metadata and 100,000 entries per archive;
200,000 retained entry references; 1,000 shared-file groups; 20 file-specific
cards and 12 shared-file cards. Hash reads are limited to 256 MiB and 15 seconds
overall, 64 MiB per whole archive and 32 MiB per asset. Files changed during the
scan and omitted or unreadable copies stay unverified. No equality is claimed
from a partial hash. Missing results do not establish difference or health.
No CAK is extracted, edited, deleted or automatically switched off.

LOCAL REPORTS
--------------
Under the existing manager data folder:
  Crash Reports/Latest crash report.txt
  Crash Reports/Same files report.txt

The same-files report lists every group retained within scan limits, including
archive names, exact internal paths, available SHA-256 hashes, file problems and
ranked investigation leads. The UI shows only the first 12 shared-file groups.
Only the latest version of each report is retained. Reports are saved locally,
never uploaded automatically, and can contain personal paths. Review before sharing.

REQUIREMENTS AND VALIDATION
---------------------------
- Windows with .NET Framework 4.8 for the desktop app and diagnostic add-on.
- The unchanged GorillaReader helper targets .NET 10. If needed, get Microsoft's
  x64 .NET 10 Runtime from https://dotnet.microsoft.com/download/dotnet/10.0 .
- WWE 2K26 and available Windows Application event records for crash evidence.
- VALIDATION.txt contains build, diagnostic, package and IL verification output.
  These checks are not antivirus scans or Windows UI/game tests.
- Linux cannot run Microsoft Defender or validate actual Windows startup, the
  new header layout or a real game crash. Those checks stay unverified.
- Your particular CAK has not been supplied or examined here.
- Only the exact original uploaded v2.0.4 executable is accepted by the builder.

Format research credit: Nenkai/Bakery. See THIRD-PARTY-NOTICES.txt.
